//
//  SendMoneyviewController.swift
//  SendMoneyTask
//
//  Created by praveenkumar on 08/03/20.
//  Copyright © 2020 praveenkumar. All rights reserved.
//

import UIKit

class SendMoneyviewController: UIViewController {
    
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var sendMoneyBtn: UIButton!
    
    var completionBlock: ((_ amount:Bool) -> Void)?
    var dict :String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        nameLable.layer.borderColor = UIColor.systemGroupedBackground.cgColor
//        nameLable.layer.borderWidth = 1.5
        
        amountTextField.layer.borderColor = UIColor.systemGroupedBackground.cgColor
        amountTextField.layer.borderWidth = 1.5
        
        sendMoneyBtn.layer.borderColor = UIColor.systemGroupedBackground.cgColor
        sendMoneyBtn.layer.borderWidth = 1.5
        nameLable.text = dict
    }
    
    @IBAction func sendMoneyBtnAction(_ sender: Any) {
        
        if amountTextField.text!.count > 0
        {
            self.completionBlock!(true)
            self.navigationController?.popViewController(animated: false)
        }
        else
        {
            self.showAlert(withTitle: "", message: "Enter Amount")
        }
    }
}
