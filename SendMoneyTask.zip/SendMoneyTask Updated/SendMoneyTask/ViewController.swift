//
//  ViewController.swift
//  SendMoneyTask
//
//  Created by praveenkumar on 07/03/20.
//  Copyright © 2020 praveenkumar. All rights reserved.
//

import UIKit

class CardCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var bankNameLable: UILabel!
    @IBOutlet weak var actNumberLable: UILabel!
    @IBOutlet weak var holderNameLable: UILabel!
    @IBOutlet weak var expiryNumberLable: UILabel!
}

class ContactsCollectionViewCell: UICollectionViewCell{
    
    @IBOutlet weak var sendImg: UIImageView!
    @IBOutlet weak var sendLable: UILabel!
    @IBOutlet weak var contactsimg: UIImageView!
    @IBOutlet weak var contactsNameLable: UILabel!
}

class SendCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var sendImg: UIImageView!
    @IBOutlet weak var sendLable: UILabel!
    @IBOutlet weak var sendView: UIView!
}

class TableViewCellOne: UITableViewCell {
    
    @IBOutlet weak var tableCellViewAllButton: UIButton!
    @IBOutlet weak var tableProImg: UIImageView!
    @IBOutlet weak var deatilBtn: UIButton!
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var paymentLable: UILabel!
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collectionViewA: UICollectionView!
    @IBOutlet weak var collectionViewB: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var viewAllButton: UIButton!
    
    var bankNamesArray :[String] = [String]()
    var cardNumbersArray :[String] = [String]()
    var cardHolderNames :[String] = [String]()
    var expeiryNumbers :[String] = [String]()
    var profileImagesArray :[String] = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.view.addSubview(collectionViewA)
        self.view.addSubview(collectionViewB)
        
        bankNamesArray = ["City Bank","Yes Bank","ICICI Bank","HDFC Bank","SBI Bank","Axis Bank"]
        cardNumbersArray = ["979164696397","632765979872","762387629863","687877887876","778865876969","676769697686"]
        cardHolderNames = ["Hulk","Iron Man","Captain America","Ant Man","Thor","Nick Fury"]
        expeiryNumbers = ["01/22","03/27","02/26","26/22","30/30","22/20"]
        profileImagesArray = ["hulk","iron-man","captain_america","antman","Thor","Nick_Fury"]
        
        self.automaticallyAdjustsScrollViewInsets = true;
        self.tableView.tableFooterView = UIView()
    }
    
    @IBAction func viewAllBtnAction(_ sender: Any) {
        
        moveToNext(string: "viewAll")
    }
    
    func moveToNext(string: String)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let composeVC = storyboard.instantiateViewController(withIdentifier: "ListTableViewController") as? ListTableViewController
        composeVC?.viewAll = string
        composeVC?.completionBlock = { localPath in
        
            if localPath == true
            {
                self.showAlert(withTitle: "", message: "Amount Send Successfully")
            }
        }
        self.navigationController?.pushViewController(composeVC!, animated: true)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        if (collectionView == self.collectionViewA)
        {
             return 1
        }
        else
        {
            return 2
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if (collectionView == self.collectionViewA)
        {
            return bankNamesArray.count
        }
        else
        {
            if section == 0
            {
                return 1
            }
            else
            {
                return cardHolderNames.count
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        if (collectionView == self.collectionViewA)
        {
            let cellA = collectionView.dequeueReusableCell(withReuseIdentifier: "CardCollectionViewCell", for: indexPath) as! CardCollectionViewCell
            
            cellA.bankNameLable.text = bankNamesArray[indexPath.row]
            cellA.actNumberLable.text = cardNumbersArray[indexPath.row]
            cellA.holderNameLable.text = cardHolderNames[indexPath.row]
            cellA.expiryNumberLable.text = expeiryNumbers[indexPath.row]
            
            return cellA
        }
        else
        {
            if indexPath.section == 0
            {
               let cellB = collectionView.dequeueReusableCell(withReuseIdentifier: "SendCollectionViewCell", for: indexPath) as! SendCollectionViewCell
                             
                cellB.sendImg.layer.cornerRadius = 30.0
                cellB.sendImg.clipsToBounds = true
                cellB.sendView.layer.borderWidth = 1
                cellB.sendView.layer.borderColor = UIColor.systemBlue.cgColor
                cellB.sendView.layer.cornerRadius = 10

                cellB.sendLable.text = "Send Money"
                cellB.sendImg.image = UIImage(named: "New_Plus_Icon")
                return cellB
            }
            else
            {
                let cellB = collectionView.dequeueReusableCell(withReuseIdentifier: "ContactsCollectionViewCell", for: indexPath) as! ContactsCollectionViewCell
                
                cellB.contactsNameLable.text = cardHolderNames[indexPath.row]
                cellB.contactsimg.image = UIImage(named: profileImagesArray[indexPath.row])
                               
                return cellB
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    
        if (collectionView == self.collectionViewB)
        {
            if indexPath.section == 0
            {
                moveToNext(string: "viewAll")
            }
        }
    }
    
    @IBAction func tableCellViewAllBtnAction(_ sender: Any) {
        
        moveToNext(string: "")
    }
    
    @IBAction func detailBtnAction(_ sender: Any) {
        
        //
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0
        {
            return 1
        }
        else
        {
            return cardHolderNames.count
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 2;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        if indexPath.section == 1
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellTwo", for: indexPath) as! TableViewCellOne
            
            cell.tableProImg.layer.cornerRadius = 20.0
            cell.tableProImg.clipsToBounds = true
            
            cell.profileName.text = cardHolderNames[indexPath.row]
            cell.paymentLable.text = bankNamesArray[indexPath.row]
            cell.tableProImg.image = UIImage(named: profileImagesArray[indexPath.row])
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellOne", for: indexPath) as! TableViewCellOne
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        if indexPath.section == 0
        {
        
        }
        else
        {
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            let composeVC = storyboard.instantiateViewController(withIdentifier: "ListTableViewController") as? ListTableViewController
            let name = cardHolderNames[indexPath.row]
            let bank = bankNamesArray[indexPath.row]
            let img = profileImagesArray[indexPath.row]
            composeVC?.viewAll = "Detail"
            composeVC?.name = name
            composeVC?.bank = bank
            composeVC?.img = img
            self.navigationController?.pushViewController(composeVC!, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 0
        {
            return 50
        }
        return 60
    }

}

extension ViewController: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if (collectionView == self.collectionViewA)
        {
            return UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 10)
        }
        else
        {
            return UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 10)
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if (collectionView == self.collectionViewA)
        {
            let collectionViewWidth = UIScreen.main.bounds.width
            print(collectionViewWidth)
            return CGSize(width: collectionViewWidth, height: collectionViewWidth/0.7)
        }
        else
        {
            let collectionViewWidth = UIScreen.main.bounds.width
            return CGSize(width: collectionViewWidth, height: collectionViewWidth)
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 10
    }
}

extension UIViewController {

    func  showAlert(withTitle:String, message:String) -> Void {
        
        let alert = UIAlertController(title: withTitle, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: {(alert: UIAlertAction!) in print("Foo")}))
        self.present(alert, animated: true, completion:nil);
    }
}


