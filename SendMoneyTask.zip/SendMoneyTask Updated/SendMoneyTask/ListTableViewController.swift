//
//  ListTableViewController.swift
//  SendMoneyTask
//
//  Created by praveenkumar on 08/03/20.
//  Copyright © 2020 praveenkumar. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var detailNameLable: UILabel!
    @IBOutlet weak var bankNameLable: UILabel!
    @IBOutlet weak var detailImgView: UIImageView!
}

class ListTableViewController: UITableViewController {
    
    var bankNamesArray :[String] = [String]()
    var cardNumbersArray :[String] = [String]()
    var cardHolderNames :[String] = [String]()
    var expeiryNumbers :[String] = [String]()
    var profileImagesArray :[String] = [String]()
    var viewAll :String = ""
    var name :String!
    var bank :String!
    var img :String!
    var completionBlock: ((_ success:Bool) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()

       bankNamesArray = ["City Bank","Yes Bank","ICICI Bank","HDFC Bank","SBI Bank","Axis Bank"]
       cardNumbersArray = ["979164696397","632765979872","762387629863","687877887876","778865876969","676769697686"]
       cardHolderNames = ["Hulk Captain America","Iron Man","Captain America","Ant Man","Thor","Nick Fury"]
       expeiryNumbers = ["1/22","3/33","2/32","26/22","30/36","22/20"]
       profileImagesArray = ["hulk","iron-man","captain_america","antman","Thor","Nick_Fury"]
        
        self.automaticallyAdjustsScrollViewInsets = true;
        self.tableView.tableFooterView = UIView()
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if viewAll == "Detail"
        {
            return 1
        }
        else
        {
            return cardHolderNames.count
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if viewAll == "viewAll"
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? TableViewCell

            cell?.imgView.image = UIImage(named: profileImagesArray[indexPath.row])
            cell?.nameLable.text = cardHolderNames[indexPath.row]
            return cell!
        }
        else
        {
            let cell = (tableView.dequeueReusableCell(withIdentifier: "TableViewCellTwo", for: indexPath) as? TableViewCell)!
            
            if viewAll == "Detail"
            {
                cell.imgView.image = UIImage(named: img)
                cell.detailNameLable.text = name
                cell.bankNameLable.text = bank
            }
            else
            {
                cell.imgView.image = UIImage(named: profileImagesArray[indexPath.row])
                cell.detailNameLable.text = cardHolderNames[indexPath.row]
                cell.bankNameLable.text = bankNamesArray[indexPath.row]
            }
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if viewAll == "viewAll"
        {
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            let composeVC = storyboard.instantiateViewController(withIdentifier: "SendMoneyviewController") as? SendMoneyviewController
            let dict = cardHolderNames[indexPath.row]
            composeVC?.dict = dict
            composeVC?.completionBlock = { localPath in
            
                if localPath == true
                {
                    self.completionBlock!(true)
                    self.navigationController?.popViewController(animated: true)
                }
            }
            self.navigationController?.pushViewController(composeVC!, animated: true)
        }
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
